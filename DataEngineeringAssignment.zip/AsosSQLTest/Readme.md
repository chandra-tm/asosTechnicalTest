#ASOS Data engineering test 

Thank you for agreeing to take part in this database coding challenge. The purpose of this test is to see how you think through problems and your attitude towards engineering practices. We will use your response to the test in a follow up discussion.

We would appreciate if you could spend a couple of hours on this. We do not expect everything to be completed, however we do expect the submitted test to build and deploy.

In any subsequent discussion we will discuss the decisions you made and your next steps.

These instructions can be found in the Readme.md of the git repo. The repo is here https://asosinterview.visualstudio.com/DataEngineerTest/_git/ and then navigate to the git repo in your name.

The repo includes the following:
- This document and companion document TestInstructions.md
- A visual studio solution containing a database project and a unit test project.
- Query plans uspCustomerOrderProductDetail.sqlplan and uspCustomerOrders.sqlplan. These are referred to in the test.

There are a number of ways to access the solution code (via the clone button to the right of the page)
- clone in Visual Studio (probably the easiest option) 
- copy the clone url and clone manually using a git command line tool such as Git Bash in combination with Visual Studio 

If you use any of the above methods then please check in your changes and any supporting documentation.
 
If you are uncomfortable with Git you can download the repo as a zip file by clicking on the ellipses "..." next to he repo name, and selecting "Download as zip". 
If you do this please upload any work to https://www.dropbox.com/request/VhZbyfc5otmAPtiKIDuQ

If you have any problems please contact us.

We would like to thank you in advance for spending the time on this, and we look forward to your response.
