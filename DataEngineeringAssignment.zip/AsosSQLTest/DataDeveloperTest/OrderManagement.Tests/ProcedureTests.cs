﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Text;
using Microsoft.Data.Tools.Schema.Sql.UnitTesting;
using Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestProject1
{
    [TestClass()]
    public class ProcedureTests : SqlDatabaseTestClass
    {

        public ProcedureTests()
        {
            InitializeComponent();
        }

        [TestInitialize()]
        public void TestInitialize()
        {
            base.InitializeTest();
        }
        [TestCleanup()]
        public void TestCleanup()
        {
            base.CleanupTest();
        }

        #region Designer support code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Microsoft.Data.Tools.Schema.Sql.UnitTesting.SqlDatabaseTestAction dbo_uspCustomerInsertTest_TestAction;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProcedureTests));
            Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition WhenInsertCustomerFirstNameIsSimon;
            Microsoft.Data.Tools.Schema.Sql.UnitTesting.SqlDatabaseTestAction dbo_uspCustomerOrderProductDetailTest_TestAction;
            Microsoft.Data.Tools.Schema.Sql.UnitTesting.SqlDatabaseTestAction dbo_uspCustomerSelectByEmailAddressTest_TestAction;
            Microsoft.Data.Tools.Schema.Sql.UnitTesting.SqlDatabaseTestAction dbo_uspOrderInsertTest_TestAction;
            Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition CustomerIdOnOrderShouldMatchWhatWasPassed;
            Microsoft.Data.Tools.Schema.Sql.UnitTesting.SqlDatabaseTestAction dbo_uspOrderProductInsertTest_TestAction;
            Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.InconclusiveCondition inconclusiveCondition5;
            Microsoft.Data.Tools.Schema.Sql.UnitTesting.SqlDatabaseTestAction dbo_uspProductInsertTest_TestAction;
            Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition scalarValueCondition1;
            Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition FirstNameIsSimon;
            Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition LastNameIsSabin;
            Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition EmailIsSimon_at_Email_dot_com;
            Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.RowCountCondition OnlyOneCustomerFound;
            Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition ProductIsApples;
            Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition PriceIs12_3;
            Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.EmptyResultSetCondition NoProductsShouldBeFoundBeforeTest;
            Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition WhenInsertCustomerLastNameIsSabin;
            Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition WhenInsertCustomerEmailIsSimon_at_email_dot_com;
            Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.RowCountCondition WhenCustomerInsertedOneRecordReturned;
            Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition WhenCustomerInsertedOnlyOneCustomerWithEmail;
            this.dbo_uspCustomerInsertTestData = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.SqlDatabaseTestActions();
            this.dbo_uspCustomerOrderProductDetailTestData = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.SqlDatabaseTestActions();
            this.dbo_uspCustomerSelectByEmailAddressTestData = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.SqlDatabaseTestActions();
            this.dbo_uspOrderInsertTestData = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.SqlDatabaseTestActions();
            this.dbo_uspOrderProductInsertTestData = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.SqlDatabaseTestActions();
            this.dbo_uspProductInsertTestData = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.SqlDatabaseTestActions();
            dbo_uspCustomerInsertTest_TestAction = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.SqlDatabaseTestAction();
            WhenInsertCustomerFirstNameIsSimon = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition();
            dbo_uspCustomerOrderProductDetailTest_TestAction = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.SqlDatabaseTestAction();
            dbo_uspCustomerSelectByEmailAddressTest_TestAction = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.SqlDatabaseTestAction();
            dbo_uspOrderInsertTest_TestAction = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.SqlDatabaseTestAction();
            CustomerIdOnOrderShouldMatchWhatWasPassed = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition();
            dbo_uspOrderProductInsertTest_TestAction = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.SqlDatabaseTestAction();
            inconclusiveCondition5 = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.InconclusiveCondition();
            dbo_uspProductInsertTest_TestAction = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.SqlDatabaseTestAction();
            scalarValueCondition1 = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition();
            FirstNameIsSimon = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition();
            LastNameIsSabin = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition();
            EmailIsSimon_at_Email_dot_com = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition();
            OnlyOneCustomerFound = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.RowCountCondition();
            ProductIsApples = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition();
            PriceIs12_3 = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition();
            NoProductsShouldBeFoundBeforeTest = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.EmptyResultSetCondition();
            WhenInsertCustomerLastNameIsSabin = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition();
            WhenInsertCustomerEmailIsSimon_at_email_dot_com = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition();
            WhenCustomerInsertedOneRecordReturned = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.RowCountCondition();
            WhenCustomerInsertedOnlyOneCustomerWithEmail = new Microsoft.Data.Tools.Schema.Sql.UnitTesting.Conditions.ScalarValueCondition();
            // 
            // dbo_uspCustomerInsertTest_TestAction
            // 
            dbo_uspCustomerInsertTest_TestAction.Conditions.Add(WhenInsertCustomerFirstNameIsSimon);
            dbo_uspCustomerInsertTest_TestAction.Conditions.Add(WhenInsertCustomerLastNameIsSabin);
            dbo_uspCustomerInsertTest_TestAction.Conditions.Add(WhenInsertCustomerEmailIsSimon_at_email_dot_com);
            dbo_uspCustomerInsertTest_TestAction.Conditions.Add(WhenCustomerInsertedOneRecordReturned);
            dbo_uspCustomerInsertTest_TestAction.Conditions.Add(WhenCustomerInsertedOnlyOneCustomerWithEmail);
            resources.ApplyResources(dbo_uspCustomerInsertTest_TestAction, "dbo_uspCustomerInsertTest_TestAction");
            // 
            // WhenInsertCustomerFirstNameIsSimon
            // 
            WhenInsertCustomerFirstNameIsSimon.ColumnNumber = 2;
            WhenInsertCustomerFirstNameIsSimon.Enabled = true;
            WhenInsertCustomerFirstNameIsSimon.ExpectedValue = "Simon";
            WhenInsertCustomerFirstNameIsSimon.Name = "WhenInsertCustomerFirstNameIsSimon";
            WhenInsertCustomerFirstNameIsSimon.NullExpected = false;
            WhenInsertCustomerFirstNameIsSimon.ResultSet = 1;
            WhenInsertCustomerFirstNameIsSimon.RowNumber = 1;
            // 
            // dbo_uspCustomerOrderProductDetailTest_TestAction
            // 
            resources.ApplyResources(dbo_uspCustomerOrderProductDetailTest_TestAction, "dbo_uspCustomerOrderProductDetailTest_TestAction");
            // 
            // dbo_uspCustomerSelectByEmailAddressTest_TestAction
            // 
            dbo_uspCustomerSelectByEmailAddressTest_TestAction.Conditions.Add(FirstNameIsSimon);
            dbo_uspCustomerSelectByEmailAddressTest_TestAction.Conditions.Add(LastNameIsSabin);
            dbo_uspCustomerSelectByEmailAddressTest_TestAction.Conditions.Add(EmailIsSimon_at_Email_dot_com);
            dbo_uspCustomerSelectByEmailAddressTest_TestAction.Conditions.Add(OnlyOneCustomerFound);
            resources.ApplyResources(dbo_uspCustomerSelectByEmailAddressTest_TestAction, "dbo_uspCustomerSelectByEmailAddressTest_TestAction");
            // 
            // dbo_uspOrderInsertTest_TestAction
            // 
            dbo_uspOrderInsertTest_TestAction.Conditions.Add(CustomerIdOnOrderShouldMatchWhatWasPassed);
            dbo_uspOrderInsertTest_TestAction.Conditions.Add(scalarValueCondition1);
            resources.ApplyResources(dbo_uspOrderInsertTest_TestAction, "dbo_uspOrderInsertTest_TestAction");
            // 
            // CustomerIdOnOrderShouldMatchWhatWasPassed
            // 
            CustomerIdOnOrderShouldMatchWhatWasPassed.ColumnNumber = 1;
            CustomerIdOnOrderShouldMatchWhatWasPassed.Enabled = true;
            CustomerIdOnOrderShouldMatchWhatWasPassed.ExpectedValue = "1";
            CustomerIdOnOrderShouldMatchWhatWasPassed.Name = "CustomerIdOnOrderShouldMatchWhatWasPassed";
            CustomerIdOnOrderShouldMatchWhatWasPassed.NullExpected = false;
            CustomerIdOnOrderShouldMatchWhatWasPassed.ResultSet = 3;
            CustomerIdOnOrderShouldMatchWhatWasPassed.RowNumber = 1;
            // 
            // dbo_uspOrderProductInsertTest_TestAction
            // 
            dbo_uspOrderProductInsertTest_TestAction.Conditions.Add(inconclusiveCondition5);
            resources.ApplyResources(dbo_uspOrderProductInsertTest_TestAction, "dbo_uspOrderProductInsertTest_TestAction");
            // 
            // inconclusiveCondition5
            // 
            inconclusiveCondition5.Enabled = true;
            inconclusiveCondition5.Name = "inconclusiveCondition5";
            // 
            // dbo_uspProductInsertTest_TestAction
            // 
            dbo_uspProductInsertTest_TestAction.Conditions.Add(ProductIsApples);
            dbo_uspProductInsertTest_TestAction.Conditions.Add(PriceIs12_3);
            dbo_uspProductInsertTest_TestAction.Conditions.Add(NoProductsShouldBeFoundBeforeTest);
            resources.ApplyResources(dbo_uspProductInsertTest_TestAction, "dbo_uspProductInsertTest_TestAction");
            // 
            // dbo_uspCustomerInsertTestData
            // 
            this.dbo_uspCustomerInsertTestData.PosttestAction = null;
            this.dbo_uspCustomerInsertTestData.PretestAction = null;
            this.dbo_uspCustomerInsertTestData.TestAction = dbo_uspCustomerInsertTest_TestAction;
            // 
            // dbo_uspCustomerOrderProductDetailTestData
            // 
            this.dbo_uspCustomerOrderProductDetailTestData.PosttestAction = null;
            this.dbo_uspCustomerOrderProductDetailTestData.PretestAction = null;
            this.dbo_uspCustomerOrderProductDetailTestData.TestAction = dbo_uspCustomerOrderProductDetailTest_TestAction;
            // 
            // dbo_uspCustomerSelectByEmailAddressTestData
            // 
            this.dbo_uspCustomerSelectByEmailAddressTestData.PosttestAction = null;
            this.dbo_uspCustomerSelectByEmailAddressTestData.PretestAction = null;
            this.dbo_uspCustomerSelectByEmailAddressTestData.TestAction = dbo_uspCustomerSelectByEmailAddressTest_TestAction;
            // 
            // dbo_uspOrderInsertTestData
            // 
            this.dbo_uspOrderInsertTestData.PosttestAction = null;
            this.dbo_uspOrderInsertTestData.PretestAction = null;
            this.dbo_uspOrderInsertTestData.TestAction = dbo_uspOrderInsertTest_TestAction;
            // 
            // dbo_uspOrderProductInsertTestData
            // 
            this.dbo_uspOrderProductInsertTestData.PosttestAction = null;
            this.dbo_uspOrderProductInsertTestData.PretestAction = null;
            this.dbo_uspOrderProductInsertTestData.TestAction = dbo_uspOrderProductInsertTest_TestAction;
            // 
            // dbo_uspProductInsertTestData
            // 
            this.dbo_uspProductInsertTestData.PosttestAction = null;
            this.dbo_uspProductInsertTestData.PretestAction = null;
            this.dbo_uspProductInsertTestData.TestAction = dbo_uspProductInsertTest_TestAction;
            // 
            // scalarValueCondition1
            // 
            scalarValueCondition1.ColumnNumber = 1;
            scalarValueCondition1.Enabled = true;
            scalarValueCondition1.ExpectedValue = "1";
            scalarValueCondition1.Name = "scalarValueCondition1";
            scalarValueCondition1.NullExpected = false;
            scalarValueCondition1.ResultSet = 2;
            scalarValueCondition1.RowNumber = 1;
            // 
            // FirstNameIsSimon
            // 
            FirstNameIsSimon.ColumnNumber = 2;
            FirstNameIsSimon.Enabled = true;
            FirstNameIsSimon.ExpectedValue = "Simon";
            FirstNameIsSimon.Name = "FirstNameIsSimon";
            FirstNameIsSimon.NullExpected = false;
            FirstNameIsSimon.ResultSet = 2;
            FirstNameIsSimon.RowNumber = 1;
            // 
            // LastNameIsSabin
            // 
            LastNameIsSabin.ColumnNumber = 3;
            LastNameIsSabin.Enabled = true;
            LastNameIsSabin.ExpectedValue = "Sabin";
            LastNameIsSabin.Name = "LastNameIsSabin";
            LastNameIsSabin.NullExpected = false;
            LastNameIsSabin.ResultSet = 2;
            LastNameIsSabin.RowNumber = 1;
            // 
            // EmailIsSimon_at_Email_dot_com
            // 
            EmailIsSimon_at_Email_dot_com.ColumnNumber = 4;
            EmailIsSimon_at_Email_dot_com.Enabled = true;
            EmailIsSimon_at_Email_dot_com.ExpectedValue = "Simon@email.com";
            EmailIsSimon_at_Email_dot_com.Name = "EmailIsSimon_at_Email_dot_com";
            EmailIsSimon_at_Email_dot_com.NullExpected = false;
            EmailIsSimon_at_Email_dot_com.ResultSet = 2;
            EmailIsSimon_at_Email_dot_com.RowNumber = 1;
            // 
            // OnlyOneCustomerFound
            // 
            OnlyOneCustomerFound.Enabled = true;
            OnlyOneCustomerFound.Name = "OnlyOneCustomerFound";
            OnlyOneCustomerFound.ResultSet = 2;
            OnlyOneCustomerFound.RowCount = 1;
            // 
            // ProductIsApples
            // 
            ProductIsApples.ColumnNumber = 2;
            ProductIsApples.Enabled = true;
            ProductIsApples.ExpectedValue = "Apples";
            ProductIsApples.Name = "ProductIsApples";
            ProductIsApples.NullExpected = false;
            ProductIsApples.ResultSet = 2;
            ProductIsApples.RowNumber = 1;
            // 
            // PriceIs12_3
            // 
            PriceIs12_3.ColumnNumber = 3;
            PriceIs12_3.Enabled = true;
            PriceIs12_3.ExpectedValue = "12.3";
            PriceIs12_3.Name = "PriceIs12_3";
            PriceIs12_3.NullExpected = false;
            PriceIs12_3.ResultSet = 2;
            PriceIs12_3.RowNumber = 1;
            // 
            // NoProductsShouldBeFoundBeforeTest
            // 
            NoProductsShouldBeFoundBeforeTest.Enabled = true;
            NoProductsShouldBeFoundBeforeTest.Name = "NoProductsShouldBeFoundBeforeTest";
            NoProductsShouldBeFoundBeforeTest.ResultSet = 1;
            // 
            // WhenInsertCustomerLastNameIsSabin
            // 
            WhenInsertCustomerLastNameIsSabin.ColumnNumber = 3;
            WhenInsertCustomerLastNameIsSabin.Enabled = true;
            WhenInsertCustomerLastNameIsSabin.ExpectedValue = "Sabin";
            WhenInsertCustomerLastNameIsSabin.Name = "WhenInsertCustomerLastNameIsSabin";
            WhenInsertCustomerLastNameIsSabin.NullExpected = false;
            WhenInsertCustomerLastNameIsSabin.ResultSet = 1;
            WhenInsertCustomerLastNameIsSabin.RowNumber = 1;
            // 
            // WhenInsertCustomerEmailIsSimon_at_email_dot_com
            // 
            WhenInsertCustomerEmailIsSimon_at_email_dot_com.ColumnNumber = 4;
            WhenInsertCustomerEmailIsSimon_at_email_dot_com.Enabled = true;
            WhenInsertCustomerEmailIsSimon_at_email_dot_com.ExpectedValue = "Simon@email.com";
            WhenInsertCustomerEmailIsSimon_at_email_dot_com.Name = "WhenInsertCustomerEmailIsSimon_at_email_dot_com";
            WhenInsertCustomerEmailIsSimon_at_email_dot_com.NullExpected = false;
            WhenInsertCustomerEmailIsSimon_at_email_dot_com.ResultSet = 1;
            WhenInsertCustomerEmailIsSimon_at_email_dot_com.RowNumber = 1;
            // 
            // WhenCustomerInsertedOneRecordReturned
            // 
            WhenCustomerInsertedOneRecordReturned.Enabled = true;
            WhenCustomerInsertedOneRecordReturned.Name = "WhenCustomerInsertedOneRecordReturned";
            WhenCustomerInsertedOneRecordReturned.ResultSet = 1;
            WhenCustomerInsertedOneRecordReturned.RowCount = 1;
            // 
            // WhenCustomerInsertedOnlyOneCustomerWithEmail
            // 
            WhenCustomerInsertedOnlyOneCustomerWithEmail.ColumnNumber = 1;
            WhenCustomerInsertedOnlyOneCustomerWithEmail.Enabled = true;
            WhenCustomerInsertedOnlyOneCustomerWithEmail.ExpectedValue = "1";
            WhenCustomerInsertedOnlyOneCustomerWithEmail.Name = "WhenCustomerInsertedOnlyOneCustomerWithEmail";
            WhenCustomerInsertedOnlyOneCustomerWithEmail.NullExpected = false;
            WhenCustomerInsertedOnlyOneCustomerWithEmail.ResultSet = 2;
            WhenCustomerInsertedOnlyOneCustomerWithEmail.RowNumber = 1;
        }

        #endregion


        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        #endregion

        [TestMethod()]
        public void dbo_uspCustomerInsertTest()
        {
            SqlDatabaseTestActions testActions = this.dbo_uspCustomerInsertTestData;
            // Execute the pre-test script
            // 
            System.Diagnostics.Trace.WriteLineIf((testActions.PretestAction != null), "Executing pre-test script...");
            SqlExecutionResult[] pretestResults = TestService.Execute(this.PrivilegedContext, this.PrivilegedContext, testActions.PretestAction);
            try
            {
                // Execute the test script
                // 
                System.Diagnostics.Trace.WriteLineIf((testActions.TestAction != null), "Executing test script...");
                SqlExecutionResult[] testResults = TestService.Execute(this.ExecutionContext, this.PrivilegedContext, testActions.TestAction);
            }
            finally
            {
                // Execute the post-test script
                // 
                System.Diagnostics.Trace.WriteLineIf((testActions.PosttestAction != null), "Executing post-test script...");
                SqlExecutionResult[] posttestResults = TestService.Execute(this.PrivilegedContext, this.PrivilegedContext, testActions.PosttestAction);
            }
        }

        [TestMethod()]
        public void dbo_uspCustomerOrderProductDetailTest()
        {
            SqlDatabaseTestActions testActions = this.dbo_uspCustomerOrderProductDetailTestData;
            // Execute the pre-test script
            // 
            System.Diagnostics.Trace.WriteLineIf((testActions.PretestAction != null), "Executing pre-test script...");
            SqlExecutionResult[] pretestResults = TestService.Execute(this.PrivilegedContext, this.PrivilegedContext, testActions.PretestAction);
            try
            {
                // Execute the test script
                // 
                System.Diagnostics.Trace.WriteLineIf((testActions.TestAction != null), "Executing test script...");
                SqlExecutionResult[] testResults = TestService.Execute(this.ExecutionContext, this.PrivilegedContext, testActions.TestAction);
            }
            finally
            {
                // Execute the post-test script
                // 
                System.Diagnostics.Trace.WriteLineIf((testActions.PosttestAction != null), "Executing post-test script...");
                SqlExecutionResult[] posttestResults = TestService.Execute(this.PrivilegedContext, this.PrivilegedContext, testActions.PosttestAction);
            }
        }

        [TestMethod()]
        public void dbo_uspCustomerSelectByEmailAddressTest()
        {
            SqlDatabaseTestActions testActions = this.dbo_uspCustomerSelectByEmailAddressTestData;
            // Execute the pre-test script
            // 
            System.Diagnostics.Trace.WriteLineIf((testActions.PretestAction != null), "Executing pre-test script...");
            SqlExecutionResult[] pretestResults = TestService.Execute(this.PrivilegedContext, this.PrivilegedContext, testActions.PretestAction);
            try
            {
                // Execute the test script
                // 
                System.Diagnostics.Trace.WriteLineIf((testActions.TestAction != null), "Executing test script...");
                SqlExecutionResult[] testResults = TestService.Execute(this.ExecutionContext, this.PrivilegedContext, testActions.TestAction);
            }
            finally
            {
                // Execute the post-test script
                // 
                System.Diagnostics.Trace.WriteLineIf((testActions.PosttestAction != null), "Executing post-test script...");
                SqlExecutionResult[] posttestResults = TestService.Execute(this.PrivilegedContext, this.PrivilegedContext, testActions.PosttestAction);
            }
        }

        [TestMethod()]
        public void dbo_uspOrderInsertTest()
        {
            SqlDatabaseTestActions testActions = this.dbo_uspOrderInsertTestData;
            // Execute the pre-test script
            // 
            System.Diagnostics.Trace.WriteLineIf((testActions.PretestAction != null), "Executing pre-test script...");
            SqlExecutionResult[] pretestResults = TestService.Execute(this.PrivilegedContext, this.PrivilegedContext, testActions.PretestAction);
            try
            {
                // Execute the test script
                // 
                System.Diagnostics.Trace.WriteLineIf((testActions.TestAction != null), "Executing test script...");
                SqlExecutionResult[] testResults = TestService.Execute(this.ExecutionContext, this.PrivilegedContext, testActions.TestAction);
            }
            finally
            {
                // Execute the post-test script
                // 
                System.Diagnostics.Trace.WriteLineIf((testActions.PosttestAction != null), "Executing post-test script...");
                SqlExecutionResult[] posttestResults = TestService.Execute(this.PrivilegedContext, this.PrivilegedContext, testActions.PosttestAction);
            }
        }

        [TestMethod()]
        public void dbo_uspOrderProductInsertTest()
        {
            SqlDatabaseTestActions testActions = this.dbo_uspOrderProductInsertTestData;
            // Execute the pre-test script
            // 
            System.Diagnostics.Trace.WriteLineIf((testActions.PretestAction != null), "Executing pre-test script...");
            SqlExecutionResult[] pretestResults = TestService.Execute(this.PrivilegedContext, this.PrivilegedContext, testActions.PretestAction);
            try
            {
                // Execute the test script
                // 
                System.Diagnostics.Trace.WriteLineIf((testActions.TestAction != null), "Executing test script...");
                SqlExecutionResult[] testResults = TestService.Execute(this.ExecutionContext, this.PrivilegedContext, testActions.TestAction);
            }
            finally
            {
                // Execute the post-test script
                // 
                System.Diagnostics.Trace.WriteLineIf((testActions.PosttestAction != null), "Executing post-test script...");
                SqlExecutionResult[] posttestResults = TestService.Execute(this.PrivilegedContext, this.PrivilegedContext, testActions.PosttestAction);
            }
        }

        [TestMethod()]
        public void dbo_uspProductInsertTest()
        {
            SqlDatabaseTestActions testActions = this.dbo_uspProductInsertTestData;
            // Execute the pre-test script
            // 
            System.Diagnostics.Trace.WriteLineIf((testActions.PretestAction != null), "Executing pre-test script...");
            SqlExecutionResult[] pretestResults = TestService.Execute(this.PrivilegedContext, this.PrivilegedContext, testActions.PretestAction);
            try
            {
                // Execute the test script
                // 
                System.Diagnostics.Trace.WriteLineIf((testActions.TestAction != null), "Executing test script...");
                SqlExecutionResult[] testResults = TestService.Execute(this.ExecutionContext, this.PrivilegedContext, testActions.TestAction);
            }
            finally
            {
                // Execute the post-test script
                // 
                System.Diagnostics.Trace.WriteLineIf((testActions.PosttestAction != null), "Executing post-test script...");
                SqlExecutionResult[] posttestResults = TestService.Execute(this.PrivilegedContext, this.PrivilegedContext, testActions.PosttestAction);
            }
        }
        private SqlDatabaseTestActions dbo_uspCustomerInsertTestData;
        private SqlDatabaseTestActions dbo_uspCustomerOrderProductDetailTestData;
        private SqlDatabaseTestActions dbo_uspCustomerSelectByEmailAddressTestData;
        private SqlDatabaseTestActions dbo_uspOrderInsertTestData;
        private SqlDatabaseTestActions dbo_uspOrderProductInsertTestData;
        private SqlDatabaseTestActions dbo_uspProductInsertTestData;
    }
}
