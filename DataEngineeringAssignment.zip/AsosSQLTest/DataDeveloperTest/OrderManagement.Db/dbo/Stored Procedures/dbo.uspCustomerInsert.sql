﻿/******************************************** Stored Procedures ***********************************************/

--Stored Procedure to Create a new Customer
CREATE PROCEDURE dbo.uspCustomerInsert
    @FirstName VARCHAR(50)
,   @Lastname VARCHAR(50)
,   @EmailAddress VARCHAR(MAX)
,   @CustomerId   INT =NULL OUTPUT
AS
    BEGIN
		
        IF NOT EXISTS ( SELECT  *
                        FROM    dbo.Customer c
                        WHERE   c.EmailAddress = @EmailAddress )
        BEGIN	

            INSERT  INTO dbo.Customer
                    (FirstName
                    ,LastName
                    ,EmailAddress
                    )
            VALUES  (@FirstName
                    ,@Lastname
                    ,@EmailAddress 
                    )
			SET @CustomerId = SCOPE_IDENTITY()
        END 

		--Return all customer Detail
        SELECT  c.CustomerId
        ,       c.FirstName
        ,       c.LastName
        ,       c.EmailAddress
        FROM    dbo.Customer c
        WHERE   c.EmailAddress = @EmailAddress
    END