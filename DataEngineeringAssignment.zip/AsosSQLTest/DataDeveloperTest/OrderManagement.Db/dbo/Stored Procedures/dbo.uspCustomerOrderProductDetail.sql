﻿/*Execute dbo.uspCustomerSelectByEmailAddress Stored Procedure
EXEC dbo.uspCustomerSelectByEmailAddress
    @EmailAddress = ''
*/


--Stored procedure to return product sales for a customer including total product sales for a customer
CREATE PROCEDURE uspCustomerOrderProductDetail (@CustomerId INT)
AS
    BEGIN	
        SELECT  c.FirstName
        ,       c.LastName
        ,       c.EmailAddress
        ,       o.OrderId
        ,       op.ProductId
        ,       ProductSpendThisOrder = op.QuantityPrice
        ,       ProductSpendTotal = SUM(op2.QuantityPrice)
        FROM    dbo.Customer c
                INNER JOIN dbo.[Order] o ON o.CustomerId = c.CustomerId
                INNER JOIN dbo.OrderProduct op ON op.OrderId = o.OrderId
                INNER JOIN dbo.OrderProduct op2 ON op2.ProductId = op.ProductId
                INNER JOIN dbo.[Order] o2 ON o2.OrderId = op2.OrderId AND
                                             o2.CustomerId = c.CustomerId
        WHERE   c.CustomerId = @CustomerId
        GROUP BY c.FirstName
        ,       c.LastName
        ,       c.EmailAddress
        ,       o.OrderId
        ,       op.ProductId
        ,       op.QuantityPrice
    END	

/*Execute dbo.uspCustomerOrderProductDetail Stored Procedure
        EXEC dbo.uspCustomerOrderProductDetail
            @CustomerId = 1
*/