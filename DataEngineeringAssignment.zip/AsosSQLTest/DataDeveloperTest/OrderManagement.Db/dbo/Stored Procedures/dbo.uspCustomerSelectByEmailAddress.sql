﻿/*Execute dbo.uspOrderProductInsert Stored Procedure
EXEC dbo.uspOrderProductInsert
    @OrderId = 1
,   @ProductCode = 1
,   @Quantity = 1 
*/


--Stored procedure to find customer detail by email address
CREATE PROCEDURE dbo.uspCustomerSelectByEmailAddress (
     @EmailAddress VARCHAR(255)
    )
AS
    BEGIN	
        SELECT  c.CustomerId
        ,       c.FirstName
        ,       c.LastName
        ,       c.EmailAddress
        FROM    dbo.Customer c
        WHERE   c.EmailAddress = @EmailAddress 
    END