﻿/*Execute dbo.uspProductInsert Stored Procedure
EXEC dbo.uspProductInsert
    @ProductCode = ''
,   @ProductName = ''
,   @Price = 00.00
*/



--Stored Procedure to Create a new Order
CREATE	PROCEDURE dbo.uspOrderInsert
    @CustomerId INT
,   @OrderId INT OUTPUT
AS
    BEGIN
        IF OBJECT_ID('tempdb..#OrderOutput','U') IS NOT NULL
            DROP TABLE tempdb..#OrderOutput; 

        CREATE TABLE #OrderOutput (OrderId INT)
		
		INSERT  INTO dbo.[Order]
                (CustomerId
                ,CreatedDate
                ,ShippedDate
                ,TotalPrice
                )
        OUTPUT  Inserted.OrderId
                INTO #OrderOutput
        VALUES  (@CustomerId
                ,GETDATE()
                ,NULL
                ,0.00 
                )

        SELECT  @OrderId = OrderId
        FROM    #OrderOutput

    END