﻿/*Execute dbo.uspCustomerSelectByEmailAddress Stored Procedure
EXEC dbo.uspCustomerSelectByEmailAddress
    @EmailAddress = ''
*/


--Stored procedure to return product sales for a customer including total product sales for a customer
CREATE PROCEDURE uspCustomerOrders (@CustomerId INT)
AS
    BEGIN	
        SELECT  c.FirstName
        ,       c.LastName
        ,       c.EmailAddress
        ,       o.OrderId
        ,       op.ProductId
        ,       op.QuantityPrice
        FROM    dbo.Customer c
                INNER JOIN dbo.[Order] o ON o.CustomerId = c.CustomerId
                INNER JOIN dbo.OrderProduct op ON op.OrderId = o.OrderId
        WHERE   c.CustomerId = @CustomerId
    END	

/*Execute dbo.uspCustomerOrderProductDetail Stored Procedure
        EXEC dbo.uspCustomerOrderProductDetail
            @CustomerId = 1
*/