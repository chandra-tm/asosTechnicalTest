﻿/*Execute dbo.uspOrderInsert Stored Procedure
DECLARE @OrderId INT 

EXEC dbo.uspOrderInsert
    @CustomerId = 1
,   @OrderId = @OrderId OUTPUT

SELECT  @OrderId
*/


--Stored Procedure to Add a product to an Order
CREATE PROCEDURE dbo.uspOrderProductInsert
    @OrderId INT
,   @ProductCode INT
,   @Quantity INT
AS
    BEGIN

        IF OBJECT_ID('tempdb..#OrderProductOutput','U') IS NOT NULL
            DROP TABLE tempdb..OrderProductOutput; 

        CREATE TABLE #OrderProductOutput (QuantityPrice MONEY)

        INSERT  INTO dbo.OrderProduct
                (OrderId
                ,ProductId
                ,Quantity
                ,Price
                ,QuantityPrice
                )
        OUTPUT  Inserted.QuantityPrice
                INTO #OrderProductOutput
        SELECT  @OrderId
        ,       p.ProductId
        ,       @Quantity
        ,       p.Price
        ,       p.Price * @Quantity
        FROM    dbo.Product p
        WHERE   p.ProductCode = @ProductCode

        UPDATE  dbo.[Order]
        SET     TotalPrice = TotalPrice + (SELECT   *
                                           FROM     #OrderProductOutput
                                          )
        WHERE   OrderId = @OrderId

    END