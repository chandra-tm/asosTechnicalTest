﻿/*Execute dbo.uspCustomerInsert Stored Procedure
EXEC dbo.uspCustomerInsert
    @FirstName = 'John'
,   @Lastname = 'Smith'
,   @EmailAddress = 'jsmith@email.com'
*/


--Stored Procedure to Create a new Product
CREATE PROCEDURE dbo.uspProductInsert
    @ProductCode INT
,   @ProductName VARCHAR(255)
,   @Price MONEY
,   @ProductId INT = NULL OUTPUT
AS
    BEGIN
	
        INSERT  INTO dbo.Product
                (ProductCode
                ,ProductName
                ,Price
                )
        VALUES  (@ProductCode
                ,@ProductName
                ,@Price 
                )

    END