﻿CREATE TABLE [dbo].[Order] (
    [OrderId]            INT            IDENTITY (1, 1) NOT NULL,
    [CustomerId]         BIGINT         NULL,
    [CreatedDate]        DATETIME       NULL,
    [ShippedDate]        DATETIME       NULL,
    [TotalPrice]         MONEY          NULL,
    [ShipToAddressLine1] NVARCHAR (255) NULL,
    [ShipToAddressLine2] NVARCHAR (255) NULL,
    [ShipToTown]         NVARCHAR (255) NULL,
    [ShipToCounty]       NVARCHAR (255) NULL,
    [ShipToPostcode]     NVARCHAR (10)  NULL,
    CONSTRAINT PK_Order PRIMARY KEY CLUSTERED ([OrderId] ASC),
    CONSTRAINT [FK_Order_CustomerId_to_Customer_CustomerId] FOREIGN KEY ([CustomerId]) REFERENCES [dbo].[Customer] ([CustomerId])
);


GO
CREATE NONCLUSTERED INDEX [IX_Order_CustomerId]
    ON [dbo].[Order]([CustomerId] ASC);

