﻿CREATE TABLE [dbo].[Product] (
    [ProductId]   INT            IDENTITY (1, 1) NOT NULL,
    [ProductCode] INT            NULL,
    [ProductName] NVARCHAR (255) NULL,
    [Price]       MONEY          NULL,
    CONSTRAINT [PK_Product] PRIMARY KEY CLUSTERED ([ProductId] ASC)
);


GO
CREATE UNIQUE NONCLUSTERED INDEX [UNCIDX_Product_ProductCode]
    ON [dbo].[Product]([ProductCode] ASC);

