﻿CREATE TABLE [dbo].[OrderProduct] (
    [OrderProductId]     INT            IDENTITY (1, 1) NOT NULL,
    [OrderId]            INT            NULL,
    [ProductId]          INT            NULL,
    [Quantity]           INT            NULL,
    [Price]              MONEY          NULL,
    [QuantityPrice]      MONEY          NULL,
    [ProductDescription] NVARCHAR (255) NULL,
    CONSTRAINT [PK_OrderProduct] PRIMARY KEY CLUSTERED ([OrderProductId] ASC),
    FOREIGN KEY ([OrderId]) REFERENCES [dbo].[Order] ([OrderId]),
    FOREIGN KEY ([ProductId]) REFERENCES [dbo].[Product] ([ProductId])
);


GO
CREATE UNIQUE NONCLUSTERED INDEX [UNCIDX_OrderProduct_OrderId_ProductId]
    ON [dbo].[OrderProduct]([OrderId] ASC, [ProductId] ASC);

