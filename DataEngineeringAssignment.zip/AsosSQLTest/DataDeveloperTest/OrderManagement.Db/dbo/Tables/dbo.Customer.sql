﻿CREATE TABLE [dbo].[Customer] (
    [CustomerId]   BIGINT         IDENTITY (1, 1) NOT NULL,
    [FirstName]    NVARCHAR (100) NULL,
    [LastName]     NVARCHAR (64)  NULL,
    [EmailAddress] NVARCHAR (255) NULL,
    [AddressLine1] NVARCHAR (255) NULL,
    [AddressLine2] NVARCHAR (255) NULL,
    [Town]         NVARCHAR (255) NULL,
    [County]       NVARCHAR (255) NULL,
    [Postcode]     NVARCHAR (10)  NULL,
    CONSTRAINT [PK_Customer] PRIMARY KEY CLUSTERED ([CustomerId] ASC)
);
go
