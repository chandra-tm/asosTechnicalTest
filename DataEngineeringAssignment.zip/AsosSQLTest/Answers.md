Please use this document to provide additional explanation to questions where requested of where you feel it is necessary.

1. Retrieving customer orders is taking a long time.
  
2. The Customer Order Product Detail procedure is taking a long time.
   
3. Developers are reporting that customers are being created with the same email address, and say the code should protect against this. 

4. The test for uspOrderProductInsert is incomplete. Please complete the testing for this procedure to meet these acceptance criteria:

5. The business has decided to allow customers to have multiple postal addresses, i.e. home, work, holiday.

6. Please review the tables and procedures.
