#Test Context
Please assume you are a developer for an on-line order processing system that operates 24x7 and is deployed to via continuous delivery. 
A number of issues have arisen that you have been asked to look at and fix.

All answers should be made to the visual studio projects. 
Where explanations are required please amend the answers.md file in your repository.
All changes need to made with consideration of being deployed to production. 

#Test Questions
These are the tasks we would you to look at
Please complete at least 3 of questions 1-5.
Please use any remaining time to do question 6, review the database.


1. Retrieving customer orders is taking a long time.
   The procedure uspCustomerOrders has been identified as being slow. The query plan for an execution is included that was previously quick but is now slow.     

   a. Using the query plan provided please explain why the execution of the procedures may be taking a long time, and what can be done about it.
   b. Please make changes to the database project in line with your recommendations.

2. The Customer Order Product Detail procedure is taking a long time.
   The procedure uspCustomerOrderProductDetail has been identified as being slow and doing lots of IO. The query plan for an execution is included

   a. Using the query plan provided please explain why the execution of the procedures may be taking a long time, and what can be done about it.
   b. Please make changes to the database project in line with your recommendations.
   
3. Developers are reporting that customers are being created with the same email address, and say the code should protect against this. 

   a. Can you review the code and provide a response as to why this may be occuring.
   b. Based on your response, please amend the database project to prevent customers being saved with the same email address.
  
4. The test for uspOrderProductInsert is incomplete. Please complete the testing for this procedure to meet these acceptance criteria:

   a. When the procedure is called a row is added to OrderProduct with the relevant values
   b. When the procedure is called and a row is added to the OrderProduct table then the Total on the Order is updated correctly.
   c. When the procedure is called for a product code already existing for the Order a constraint violation should occur.

5. The business has decided to allow customers to have multiple postal addresses, i.e. home, work, holiday.

   a. Please change the database project to be able to support this.
   b. Consideration needs to be made as to how the change would be released. Bearing in mind the system operates 24/7, please provide details of the release process. 
      We would appreciate if you would provide these answers via the answers.md file. 

6. Review
Please review the tables and procedures.

   a. Assume that your team was responsible for this database, what would you put forward to your team to change and why?
